#!/bin/sh

#  InstallLibraries.sh
#  ConkyX
#
#  Created by Nikolas Pylarinos on 27/01/2018.
#  Copyright © 2018 Nikolas Pylarinos. All rights reserved.

/usr/local/bin/brew install cmake freetype gettext lua imlib2
