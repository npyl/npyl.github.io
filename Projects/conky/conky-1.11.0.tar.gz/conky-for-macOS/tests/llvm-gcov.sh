#!/bin/bash
exec llvm-cov-7 gcov "$@"
